package com.example.test3_21nov

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
